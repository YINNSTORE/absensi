# Absensi MTs-Al Basroh

Sistem absensi siswa modern berbasis Next.js + TypeScript.

## Fitur starter
- Login demo dengan role Admin, Guru, Siswa
- Dashboard premium tema biru
- Light / Dark mode
- QR siswa
- Scanner QR
- Notifikasi sukses/gagal
- Responsive mobile
- GitHub Actions CI
- Struktur siap dikembangkan ke database PostgreSQL

## Menjalankan lokal

```bash
npm install
npm run dev
```

Buka `http://localhost:3000`.

### Akun demo
- Admin: `admin` / `admin123`
- Guru: `guru` / `guru123`
- Siswa: `siswa` / `siswa123`

> Akun di atas hanya untuk demo UI. Jangan dipakai untuk production.

## Struktur utama

```text
app/
  login/
  dashboard/
  qr/
  scanner/
components/
lib/
prisma/
.github/workflows/
```

## Tahap berikutnya
1. PostgreSQL + Prisma
2. Auth production
3. CRUD siswa/guru/kelas
4. QR session dinamis
5. Absensi server-side
6. Rekap dan export laporan
7. Push notification

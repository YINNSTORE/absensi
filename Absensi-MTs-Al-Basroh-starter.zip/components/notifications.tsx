"use client";

import { useEffect, useState } from "react";
import { CheckCircle2, Info, TriangleAlert, XCircle, X } from "lucide-react";

type Item = {
  id: number;
  type: "success" | "error" | "warning" | "info";
  title: string;
  message: string;
};

export default function Notifications() {
  const [items, setItems] = useState<Item[]>([]);

  useEffect(() => {
    const handler = (event: Event) => {
      const detail = (event as CustomEvent).detail;
      const item = { id: Date.now(), ...detail } as Item;
      setItems(prev => [...prev, item]);
      setTimeout(() => {
        setItems(prev => prev.filter(x => x.id !== item.id));
      }, 4500);
    };

    window.addEventListener("amb-notify", handler);
    return () => window.removeEventListener("amb-notify", handler);
  }, []);

  const icon = {
    success: <CheckCircle2 className="text-emerald-500" />,
    error: <XCircle className="text-red-500" />,
    warning: <TriangleAlert className="text-amber-500" />,
    info: <Info className="text-blue-500" />,
  };

  return (
    <div className="fixed right-4 top-4 z-50 flex w-[calc(100%-2rem)] max-w-sm flex-col gap-3">
      {items.map(item => (
        <div key={item.id} className="card flex gap-3 p-4 shadow-2xl shadow-slate-950/10">
          {icon[item.type]}
          <div className="min-w-0 flex-1">
            <p className="font-black">{item.title}</p>
            <p className="mt-1 text-sm text-slate-500">{item.message}</p>
          </div>
          <button onClick={() => setItems(prev => prev.filter(x => x.id !== item.id))}>
            <X size={16} className="text-slate-400" />
          </button>
        </div>
      ))}
    </div>
  );
}

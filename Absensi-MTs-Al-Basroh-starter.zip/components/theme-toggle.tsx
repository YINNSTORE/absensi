"use client";

import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  if (!mounted) return <button className="btn-secondary">Tema</button>;

  const dark = theme === "dark";

  return (
    <button className="btn-secondary" onClick={() => setTheme(dark ? "light" : "dark")} aria-label="Ganti tema">
      {dark ? <Sun size={17} /> : <Moon size={17} />}
      {dark ? "Siang" : "Malam"}
    </button>
  );
}

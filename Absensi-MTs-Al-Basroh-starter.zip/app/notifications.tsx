import Notifications from "@/components/notifications";

export default function NotificationMount() {
  return <Notifications />;
}

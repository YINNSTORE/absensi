import type { Metadata } from "next";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import Notifications from "@/components/notifications";

export const metadata: Metadata = {
  title: "Absensi MTs-Al Basroh",
  description: "Sistem absensi siswa MTs-Al Basroh",
  applicationName: "Absensi MTs-Al Basroh",
  manifest: "/manifest.webmanifest",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body>
        <ThemeProvider>{children}<Notifications /></ThemeProvider>
      </body>
    </html>
  );
}

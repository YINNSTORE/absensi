"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { LogIn, ShieldCheck } from "lucide-react";
import { notify } from "@/lib/notify";

const accounts = {
  admin: { password: "admin123", role: "ADMIN", name: "Administrator" },
  guru: { password: "guru123", role: "GURU", name: "Guru Demo" },
  siswa: { password: "siswa123", role: "SISWA", name: "Siswa Demo" },
};

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  function submit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);

    const account = accounts[username as keyof typeof accounts];

    setTimeout(() => {
      setLoading(false);

      if (!account || account.password !== password) {
        notify("error", "Login gagal", "Username atau password tidak benar.");
        return;
      }

      localStorage.setItem("amb-role", account.role);
      localStorage.setItem("amb-name", account.name);
      notify("success", "Login berhasil", `Selamat datang, ${account.name}.`);
      router.push("/dashboard");
    }, 450);
  }

  return (
    <main className="min-h-screen grid lg:grid-cols-2">
      <section className="hidden lg:flex relative overflow-hidden bg-blue-700 p-12 text-white">
        <div className="absolute -right-28 -top-28 h-80 w-80 rounded-full bg-white/10" />
        <div className="absolute -bottom-32 -left-20 h-96 w-96 rounded-full bg-blue-400/20" />

        <div className="relative z-10 max-w-xl self-center">
          <div className="mb-8 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15">
            <ShieldCheck size={30} />
          </div>
          <p className="mb-3 text-sm font-bold uppercase tracking-[.2em] text-blue-100">
            MTs-Al Basroh
          </p>
          <h1 className="text-5xl font-black leading-tight">
            Absensi sekolah yang cepat, aman, dan modern.
          </h1>
          <p className="mt-6 text-lg leading-8 text-blue-100">
            Kelola kehadiran siswa menggunakan QR Code dengan pengalaman yang sederhana untuk guru, siswa, dan admin.
          </p>
        </div>
      </section>

      <section className="flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-600 text-white">
              <ShieldCheck />
            </div>
            <h2 className="text-3xl font-black">Selamat datang</h2>
            <p className="mt-2 text-slate-500">Masuk ke Absensi MTs-Al Basroh.</p>
          </div>

          <form onSubmit={submit} className="card p-6 shadow-xl shadow-blue-950/5">
            <label className="mb-2 block text-sm font-bold">Username</label>
            <input className="input mb-5" value={username} onChange={e => setUsername(e.target.value)} placeholder="Masukkan username" autoComplete="username" />

            <label className="mb-2 block text-sm font-bold">Password</label>
            <input className="input mb-6" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Masukkan password" autoComplete="current-password" />

            <button className="btn-primary w-full" disabled={loading}>
              <LogIn size={18} />
              {loading ? "Memproses..." : "Masuk"}
            </button>

            <div className="mt-5 rounded-xl bg-blue-50 p-4 text-sm text-blue-800 dark:bg-blue-950/30 dark:text-blue-200">
              Demo: <b>admin/admin123</b>, <b>guru/guru123</b>, atau <b>siswa/siswa123</b>.
            </div>
          </form>
        </div>
      </section>
    </main>
  );
}

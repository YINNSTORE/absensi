"use client";

import { useEffect, useMemo, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { ArrowLeft, RefreshCw, ShieldCheck } from "lucide-react";
import { useRouter } from "next/navigation";

export default function QRPage() {
  const router = useRouter();
  const [seconds, setSeconds] = useState(60);
  const [token, setToken] = useState("");

  const makeToken = () => {
    const random = crypto.randomUUID().replaceAll("-", "");
    setToken(`AMB-${random}`);
    setSeconds(60);
  };

  useEffect(() => {
    makeToken();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setSeconds(s => {
        if (s <= 1) {
          makeToken();
          return 60;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const value = useMemo(() => JSON.stringify({
    app: "Absensi MTs-Al Basroh",
    type: "ATTENDANCE_SESSION",
    token
  }), [token]);

  return (
    <main className="min-h-screen p-5">
      <div className="mx-auto max-w-3xl">
        <button className="btn-secondary mb-5" onClick={() => router.back()}>
          <ArrowLeft size={17} /> Kembali
        </button>

        <div className="card overflow-hidden">
          <div className="bg-blue-600 p-7 text-white">
            <p className="text-sm font-bold uppercase tracking-widest text-blue-100">Guru</p>
            <h1 className="mt-1 text-3xl font-black">QR Absensi</h1>
            <p className="mt-2 text-blue-100">Siswa scan QR ini untuk mencatat kehadiran.</p>
          </div>

          <div className="p-8 text-center">
            <div className="mx-auto w-fit rounded-3xl bg-white p-5 shadow-2xl">
              <QRCodeSVG value={value} size={270} level="M" />
            </div>

            <div className="mx-auto mt-6 max-w-sm rounded-2xl bg-blue-50 p-4 text-blue-800 dark:bg-blue-950/30 dark:text-blue-200">
              <p className="text-sm font-semibold">QR berganti otomatis</p>
              <p className="mt-1 text-4xl font-black">{seconds}s</p>
            </div>

            <div className="mt-5 flex flex-wrap justify-center gap-3">
              <button className="btn-primary" onClick={makeToken}>
                <RefreshCw size={17} /> Ganti QR
              </button>
              <span className="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold dark:border-slate-800">
                <ShieldCheck size={17} /> Token sementara
              </span>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

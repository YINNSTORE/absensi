"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { BarChart3, BookOpen, CalendarCheck, LogOut, QrCode, ScanLine, Users } from "lucide-react";
import ThemeToggle from "@/components/theme-toggle";

export default function DashboardPage() {
  const router = useRouter();
  const [role, setRole] = useState("SISWA");
  const [name, setName] = useState("Pengguna");

  useEffect(() => {
    const r = localStorage.getItem("amb-role");
    const n = localStorage.getItem("amb-name");
    if (!r) router.replace("/login");
    else {
      setRole(r);
      setName(n || "Pengguna");
    }
  }, [router]);

  function logout() {
    localStorage.clear();
    router.push("/login");
  }

  const roleLabel = role === "ADMIN" ? "Administrator" : role === "GURU" ? "Guru" : "Siswa";

  return (
    <main className="min-h-screen">
      <header className="border-b border-slate-200/80 bg-white/80 backdrop-blur dark:border-slate-800 dark:bg-slate-950/80">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-blue-600">MTs-Al Basroh</p>
            <h1 className="text-xl font-black">Absensi Dashboard</h1>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <button onClick={logout} className="btn-secondary">
              <LogOut size={17} /> Keluar
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-5 py-8">
        <div className="mb-8">
          <p className="text-sm text-slate-500">Dashboard {roleLabel}</p>
          <h2 className="mt-1 text-3xl font-black">Halo, {name} 👋</h2>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Kehadiran Hari Ini", "94,8%", CalendarCheck],
            ["Siswa Hadir", "301", Users],
            ["Terlambat", "12", BarChart3],
            ["Kelas Aktif", "18", BookOpen],
          ].map(([label, value, Icon]) => (
            <div className="card p-5" key={label as string}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-500">{label as string}</p>
                  <p className="mt-2 text-3xl font-black">{value as string}</p>
                </div>
                <div className="rounded-2xl bg-blue-50 p-3 text-blue-600 dark:bg-blue-950/40">
                  <Icon size={22} />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          <div className="card p-6 lg:col-span-2">
            <div className="mb-5 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black">Aktivitas Absensi</h3>
                <p className="text-sm text-slate-500">Ringkasan aktivitas terbaru.</p>
              </div>
              <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">LIVE</span>
            </div>
            <div className="space-y-3">
              {["Kelas VII-A • 28 siswa hadir", "Kelas VIII-B • 31 siswa hadir", "Kelas IX-A • 29 siswa hadir", "Kelas VII-B • 30 siswa hadir"].map((item, i) => (
                <div key={i} className="flex items-center justify-between rounded-xl border border-slate-100 p-4 dark:border-slate-800">
                  <span className="font-semibold">{item}</span>
                  <span className="text-xs text-slate-500">{i + 1} menit lalu</span>
                </div>
              ))}
            </div>
          </div>

          <div className="card p-6">
            <h3 className="text-lg font-black">Aksi Cepat</h3>
            <div className="mt-5 space-y-3">
              {(role === "GURU" || role === "ADMIN") && (
                <button onClick={() => router.push("/qr")} className="btn-primary w-full">
                  <QrCode size={18} /> Buat QR Absensi
                </button>
              )}
              <button onClick={() => router.push("/scanner")} className="btn-secondary w-full">
                <ScanLine size={18} /> Scan QR
              </button>
              <button className="btn-secondary w-full">
                <CalendarCheck size={18} /> Riwayat Absensi
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

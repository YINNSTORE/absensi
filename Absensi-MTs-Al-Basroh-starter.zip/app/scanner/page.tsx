"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Camera, CheckCircle2, XCircle } from "lucide-react";
import { useRouter } from "next/navigation";
import { notify } from "@/lib/notify";

export default function ScannerPage() {
  const router = useRouter();
  const scannerRef = useRef<HTMLDivElement>(null);
  const [result, setResult] = useState<string | null>(null);

  useEffect(() => {
    let scanner: any;

    async function start() {
      const { Html5Qrcode } = await import("html5-qrcode");
      if (!scannerRef.current) return;

      scanner = new Html5Qrcode("qr-reader");

      try {
        await scanner.start(
          { facingMode: "environment" },
          { fps: 10, qrbox: { width: 240, height: 240 } },
          (decoded: string) => {
            setResult(decoded);
            notify("success", "Absensi berhasil", "QR Code berhasil terbaca. Pada tahap production, server akan memvalidasi sesi ini.");
            scanner.stop().catch(() => {});
          },
          () => {}
        );
      } catch {
        notify("error", "Kamera gagal dibuka", "Pastikan izin kamera diberikan kepada aplikasi/browser.");
      }
    }

    start();

    return () => {
      if (scanner) scanner.stop().catch(() => {});
    };
  }, []);

  return (
    <main className="min-h-screen p-5">
      <div className="mx-auto max-w-2xl">
        <button className="btn-secondary mb-5" onClick={() => router.back()}>
          <ArrowLeft size={17} /> Kembali
        </button>

        <div className="card overflow-hidden">
          <div className="bg-blue-600 p-7 text-white">
            <p className="text-sm font-bold uppercase tracking-widest text-blue-100">Siswa</p>
            <h1 className="mt-1 text-3xl font-black">Scan QR Absensi</h1>
            <p className="mt-2 text-blue-100">Arahkan kamera ke QR yang ditampilkan guru.</p>
          </div>

          <div className="p-6">
            {!result && (
              <div className="mb-5 flex items-center gap-3 rounded-2xl bg-blue-50 p-4 text-blue-800 dark:bg-blue-950/30 dark:text-blue-200">
                <Camera size={22} />
                <span className="text-sm font-semibold">Kamera sedang dipersiapkan...</span>
              </div>
            )}

            <div id="qr-reader" ref={scannerRef} className="overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800" />

            {result && (
              <div className="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-5 dark:border-emerald-900 dark:bg-emerald-950/30">
                <div className="flex gap-3">
                  <CheckCircle2 className="shrink-0 text-emerald-600" />
                  <div>
                    <h2 className="font-black text-emerald-800 dark:text-emerald-300">QR terbaca</h2>
                    <p className="mt-1 break-all text-sm text-emerald-700 dark:text-emerald-400">{result}</p>
                  </div>
                </div>
              </div>
            )}

            {!result && (
              <div className="mt-5 flex items-center gap-2 text-sm text-slate-500">
                <XCircle size={17} /> Belum ada QR yang terbaca.
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}

export type NotifyType = "success" | "error" | "warning" | "info";

export function notify(type: NotifyType, title: string, message: string) {
  window.dispatchEvent(
    new CustomEvent("amb-notify", {
      detail: { type, title, message },
    })
  );
}
